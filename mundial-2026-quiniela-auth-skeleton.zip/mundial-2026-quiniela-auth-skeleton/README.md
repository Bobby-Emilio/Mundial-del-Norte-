# Mundial 2026 Quiniela — Auth Skeleton

This starter skeleton covers **The Door**:

- Supabase login
- Supabase signup
- User profile creation
- Protected dashboard
- Join league by invite code
- Supabase server/browser clients
- Starter SQL for users, leagues, and memberships

## Install

```bash
npm install
cp .env.example .env.local
npm run dev
```

## Supabase setup

1. Create Supabase project.
2. Copy URL and anon key into `.env.local`.
3. Run `supabase/001_auth_league_schema.sql` in Supabase SQL editor.
4. Enable Email Auth in Supabase Authentication settings.
5. Start app locally.

## App routes

| Route | Purpose |
|---|---|
| `/login` | Login |
| `/signup` | Create account |
| `/join` | Join private league |
| `/app` | Protected dashboard |
