import { requireUser } from "@/lib/auth/requireUser";
import { createClient } from "@/lib/supabase/server";
import Link from "next/link";

export default async function DashboardPage() {
  const user = await requireUser();
  const supabase = await createClient();

  const { data: memberships } = await supabase
    .from("league_members")
    .select("role, payment_status, leagues(name, stake_amount)")
    .eq("user_id", user.id);

  return (
    <main className="min-h-screen p-6">
      <section className="mx-auto max-w-3xl space-y-6">
        <div>
          <p className="text-sm text-slate-400">Dashboard</p>
          <h1 className="text-3xl font-bold">Mundial 2026 Quiniela</h1>
        </div>

        {!memberships?.length ? (
          <div className="rounded-2xl bg-slate-900 border border-slate-700 p-5">
            <h2 className="font-semibold">No league joined yet</h2>
            <p className="text-slate-400 mt-1">Enter your private invite code.</p>
            <Link className="inline-block mt-4 rounded-xl bg-white text-slate-950 px-4 py-2 font-semibold" href="/join">
              Join League
            </Link>
          </div>
        ) : (
          <div className="grid gap-4">
            {memberships.map((m: any, index: number) => (
              <div key={index} className="rounded-2xl bg-slate-900 border border-slate-700 p-5">
                <h2 className="text-xl font-bold">{m.leagues?.name}</h2>
                <p className="text-slate-400">Role: {m.role}</p>
                <p className="text-slate-400">Payment: {m.payment_status}</p>
                <p className="text-slate-400">Stake: ${m.leagues?.stake_amount}</p>
              </div>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
