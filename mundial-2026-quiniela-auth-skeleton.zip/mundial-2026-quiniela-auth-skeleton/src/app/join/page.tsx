import { requireUser } from "@/lib/auth/requireUser";
import { JoinLeagueForm } from "@/components/auth/JoinLeagueForm";
import { Card } from "@/components/ui/Card";

export default async function JoinPage() {
  const user = await requireUser();

  return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <Card>
          <h1 className="text-2xl font-bold">Join League</h1>
          <p className="text-slate-400 mt-1 mb-5">
            Enter the invite code from the admin.
          </p>
          <JoinLeagueForm userId={user.id} />
        </Card>
      </div>
    </main>
  );
}
