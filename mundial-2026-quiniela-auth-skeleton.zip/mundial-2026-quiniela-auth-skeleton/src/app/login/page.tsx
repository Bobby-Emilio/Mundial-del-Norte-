import Link from "next/link";
import { LoginForm } from "@/components/auth/LoginForm";
import { Card } from "@/components/ui/Card";

export default function LoginPage() {
  return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md space-y-4">
        <Card>
          <h1 className="text-2xl font-bold">Login</h1>
          <p className="text-slate-400 mt-1 mb-5">Enter the private league door.</p>
          <LoginForm />
        </Card>

        <p className="text-center text-sm text-slate-400">
          No account? <Link className="underline" href="/signup">Create one</Link>
        </p>
      </div>
    </main>
  );
}
