import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <section className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 p-6 space-y-6">
        <div>
          <p className="text-sm text-slate-400">Mundial 2026</p>
          <h1 className="text-3xl font-bold">Quiniela App</h1>
          <p className="mt-2 text-slate-300">
            Private friends-only prediction league.
          </p>
        </div>

        <div className="grid gap-3">
          <Link className="rounded-xl bg-white text-slate-950 text-center py-3 font-semibold" href="/login">
            Login
          </Link>
          <Link className="rounded-xl border border-slate-600 text-center py-3 font-semibold" href="/signup">
            Create account
          </Link>
        </div>
      </section>
    </main>
  );
}
