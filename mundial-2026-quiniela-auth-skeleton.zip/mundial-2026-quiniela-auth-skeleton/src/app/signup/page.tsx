import Link from "next/link";
import { SignupForm } from "@/components/auth/SignupForm";
import { Card } from "@/components/ui/Card";

export default function SignupPage() {
  return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md space-y-4">
        <Card>
          <h1 className="text-2xl font-bold">Create account</h1>
          <p className="text-slate-400 mt-1 mb-5">Create your player profile.</p>
          <SignupForm />
        </Card>

        <p className="text-center text-sm text-slate-400">
          Already have account? <Link className="underline" href="/login">Login</Link>
        </p>
      </div>
    </main>
  );
}
