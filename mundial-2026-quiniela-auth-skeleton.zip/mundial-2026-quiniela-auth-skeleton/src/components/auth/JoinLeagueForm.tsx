"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

export function JoinLeagueForm({ userId }: { userId: string }) {
  const router = useRouter();
  const supabase = createClient();

  const [inviteCode, setInviteCode] = useState("");
  const [message, setMessage] = useState("");

  async function handleJoin(e: React.FormEvent) {
    e.preventDefault();
    setMessage("Checking invite code...");

    const { data: league, error: leagueError } = await supabase
      .from("leagues")
      .select("id")
      .eq("invite_code", inviteCode.trim())
      .single();

    if (leagueError || !league) {
      setMessage("Invalid invite code.");
      return;
    }

    const { error: joinError } = await supabase.from("league_members").upsert({
      league_id: league.id,
      user_id: userId,
      role: "player",
      payment_status: "unpaid",
    });

    if (joinError) {
      setMessage(joinError.message);
      return;
    }

    router.push("/app");
    router.refresh();
  }

  return (
    <form onSubmit={handleJoin} className="space-y-4">
      <input
        className="w-full rounded-xl bg-slate-800 border border-slate-600 px-4 py-3 uppercase"
        placeholder="Invite code"
        value={inviteCode}
        onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
      />

      <button className="w-full rounded-xl bg-white text-slate-950 py-3 font-semibold">
        Join League
      </button>

      {message && <p className="text-sm text-slate-300">{message}</p>}
    </form>
  );
}
