"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

export function LoginForm() {
  const router = useRouter();
  const supabase = createClient();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setMessage("Checking credentials...");

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      setMessage(error.message);
      return;
    }

    router.push("/app");
    router.refresh();
  }

  return (
    <form onSubmit={handleLogin} className="space-y-4">
      <input
        className="w-full rounded-xl bg-slate-800 border border-slate-600 px-4 py-3"
        placeholder="Email"
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />

      <input
        className="w-full rounded-xl bg-slate-800 border border-slate-600 px-4 py-3"
        placeholder="Password"
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />

      <button className="w-full rounded-xl bg-white text-slate-950 py-3 font-semibold">
        Login
      </button>

      {message && <p className="text-sm text-slate-300">{message}</p>}
    </form>
  );
}
