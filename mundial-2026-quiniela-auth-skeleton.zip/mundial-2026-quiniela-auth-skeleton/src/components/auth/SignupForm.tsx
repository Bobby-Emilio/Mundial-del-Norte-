"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

export function SignupForm() {
  const router = useRouter();
  const supabase = createClient();

  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault();
    setMessage("Creating account...");

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) {
      setMessage(error.message);
      return;
    }

    const user = data.user;

    if (user) {
      await supabase.from("users").insert({
        id: user.id,
        email,
        display_name: displayName,
      });
    }

    setMessage("Account created. Check email if confirmation is enabled.");
    router.push("/join");
    router.refresh();
  }

  return (
    <form onSubmit={handleSignup} className="space-y-4">
      <input
        className="w-full rounded-xl bg-slate-800 border border-slate-600 px-4 py-3"
        placeholder="Display name"
        value={displayName}
        onChange={(e) => setDisplayName(e.target.value)}
      />

      <input
        className="w-full rounded-xl bg-slate-800 border border-slate-600 px-4 py-3"
        placeholder="Email"
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />

      <input
        className="w-full rounded-xl bg-slate-800 border border-slate-600 px-4 py-3"
        placeholder="Password"
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />

      <button className="w-full rounded-xl bg-white text-slate-950 py-3 font-semibold">
        Create account
      </button>

      {message && <p className="text-sm text-slate-300">{message}</p>}
    </form>
  );
}
