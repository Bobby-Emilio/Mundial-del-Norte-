export function Card({ children }: { children: React.ReactNode }) {
  return (
    <section className="rounded-2xl bg-slate-900 border border-slate-700 p-5 shadow">
      {children}
    </section>
  );
}
