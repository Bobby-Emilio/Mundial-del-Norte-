import { redirect } from "next/navigation";
import { getUser } from "./getUser";

export async function requireUser() {
  const user = await getUser();

  if (!user) {
    redirect("/login");
  }

  return user;
}
