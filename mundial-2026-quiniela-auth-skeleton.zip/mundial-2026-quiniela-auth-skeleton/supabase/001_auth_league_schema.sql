create extension if not exists "uuid-ossp";

create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  email text unique not null,
  created_at timestamptz default now()
);

create table if not exists public.leagues (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  invite_code text unique not null,
  stake_amount numeric(10,2) default 100,
  prize_first_pct numeric(5,2) default 70,
  prize_second_pct numeric(5,2) default 20,
  prize_third_pct numeric(5,2) default 10,
  created_by uuid references public.users(id),
  created_at timestamptz default now()
);

create table if not exists public.league_members (
  id uuid primary key default uuid_generate_v4(),
  league_id uuid references public.leagues(id) on delete cascade,
  user_id uuid references public.users(id) on delete cascade,
  role text check (role in ('admin','player')) default 'player',
  payment_status text check (payment_status in ('unpaid','paid','waived')) default 'unpaid',
  joined_at timestamptz default now(),
  unique (league_id, user_id)
);

alter table public.users enable row level security;
alter table public.leagues enable row level security;
alter table public.league_members enable row level security;

create policy "Users can read own profile"
on public.users for select
using (auth.uid() = id);

create policy "Users can insert own profile"
on public.users for insert
with check (auth.uid() = id);

create policy "Users can update own profile"
on public.users for update
using (auth.uid() = id)
with check (auth.uid() = id);

create policy "Authenticated users can find league by invite code"
on public.leagues for select
to authenticated
using (true);

create policy "League creators can insert leagues"
on public.leagues for insert
to authenticated
with check (created_by = auth.uid());

create policy "Members can read their memberships"
on public.league_members for select
to authenticated
using (user_id = auth.uid());

create policy "Users can join leagues as themselves"
on public.league_members for insert
to authenticated
with check (user_id = auth.uid());

create policy "Users can upsert their own membership"
on public.league_members for update
to authenticated
using (user_id = auth.uid())
with check (user_id = auth.uid());

-- Temporary seed example.
-- Replace created_by with a real user id after signup if creating manually.
-- insert into public.leagues (name, invite_code, stake_amount)
-- values ('Mundial 2026 Friends League', 'MUNDIAL2026', 100);
